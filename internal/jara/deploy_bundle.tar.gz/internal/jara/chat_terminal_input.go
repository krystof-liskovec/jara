//go:build linux || darwin

package jara

import (
	"strconv"
	"strings"
)

// handleKey applies one key or paste event; done means the interface exits.
func (t *chatTerminal) handleKey(event chatTerminalKeyEvent) (done bool, err error) {
	u := t.u
	if event.leave {
		// Ctrl+D on an empty input box detaches: the window closes and the
		// session keeps running, idle or not, to come back to later. With
		// text typed it deletes the character at the cursor.
		if t.editor.Text() == "" {
			t.dirty = true
			if u.persistentSession {
				return t.submit("/detach")
			}
			return t.submit("/quit")
		}
		event.input = &chatEditorInput{Key: chatEditorDelete}
	}
	if event.input != nil && event.input.Key == chatEditorEscape && !u.diff.fullScreen() {
		return false, t.handleEscape(*event.input)
	}
	if u.diff.fullScreen() && t.handleFullScreenDiffKey(event) {
		return false, nil
	}
	switch {
	case event.scrollRows != 0:
		t.scroll(t.scrollOffset + event.scrollRows)
		return false, nil
	case event.scroll != 0:
		t.scroll(t.scrollOffset + event.scroll*max(1, heightForChatTerminal(t.output)/2))
		return false, nil
	case event.diffPane || event.paneScroll != 0:
		handleChatPaneKey(&u.diff, event, t.output)
		t.dirty = true
		return false, nil
	case event.returnToLive:
		t.scroll(0)
		return false, nil
	case event.agentStep != 0:
		t.showAgent(func() { u.cycleChatAgentView(event.agentStep) })
		return false, nil
	case event.reasoningStep != 0:
		if err := u.stepChatReasoning(event.reasoningStep); err != nil {
			u.printRole("system", err.Error()+"\n")
		}
		t.dirty = true
		return false, nil
	case event.autoMode:
		u.toggleAutoMode()
		t.dirty = true
		return false, nil
	case event.interrupt:
		return t.interrupt()
	case event.tap != nil:
		return t.tap(event.tap[0], event.tap[1])
	case event.input == nil:
		return false, nil
	}
	input := event.input
	switch input.Key {
	case chatEditorModelPicker:
		t.openPicker("model")
		return false, nil
	case chatEditorReasoningPicker:
		t.openPicker("reasoning")
		return false, nil
	}
	chatTerminalAttachImages(u, input)
	menuOpen := t.picker.active() || t.sessionPicker || t.queueEditor.active()
	if answer := chatApprovalKey(u, t.editor, *input); answer != "" && !(menuOpen && input.Key == chatEditorEnter) {
		t.dirty = true
		return u.line(answer)
	}
	if handled, err := t.handleQuestionKey(*input); handled || err != nil {
		t.dirty = true
		return false, err
	}
	if t.handlePickerKey(*input) || t.handleSessionPickerKey(*input) {
		t.dirty = true
		if line := u.pendingLine; line != "" { // a menu choice that runs a command
			u.pendingLine = ""
			return t.submit(line)
		}
		return false, nil
	}
	if t.leftOpensSessions(*input) {
		t.dirty = true
		return t.submit("/resume")
	}
	if t.queueEditor.active() && input.Key == chatEditorEscape {
		t.queueEditor.cancel(u, t.editor)
		t.scroll(0)
		return false, nil
	}
	if t.queueOnTab(*input) {
		t.dirty = true
		return false, nil
	}
	t.editor.private = u.login.secret != ""
	result := t.editor.Apply(*input)
	if result.Changed && !t.editor.private {
		u.noteChatComposer(t.editor.Text(), t.editor.CursorByte())
	}
	if result.LimitReached || event.limitReached {
		t.transcript.append("system", "Input reached the size limit; the remaining text was omitted.\n")
	}
	t.dirty = t.dirty || result.Changed || result.LimitReached || event.limitReached
	if !result.Submitted {
		return false, nil
	}
	return t.submit(result.Value)
}

func (t *chatTerminal) scroll(offset int) {
	t.scrollOffset, t.dirty = max(0, offset), true
}

func (t *chatTerminal) openPicker(kind string) {
	t.sessionPicker, t.resumePickerPending = false, false
	if err := t.picker.request(t.u, kind); err != nil {
		t.u.pickerRequested = ""
		t.transcript.append("system", chatPickerErrorText("Could not open picker", err)+"\n")
	}
	t.dirty = true
}

// handleEscape applies Escape: it closes or steps back out of whatever is
// open, the innermost first; with nothing open it stops a running turn, as
// Ctrl+C does. A waiting question is left alone, so a stray Escape does not
// throw it away.
func (t *chatTerminal) handleEscape(input chatEditorInput) error {
	u := t.u
	t.dirty = true
	switch {
	case u.diff.fullScreen():
		u.diff.hideOnScreen()
		return nil
	case t.queueEditor.active():
		t.queueEditor.cancel(u, t.editor)
		t.scroll(0)
		return nil
	case t.handlePickerKey(input) || t.handleSessionPickerKey(input):
		return nil
	case u.login.secret != "":
		t.editor.SetText("")
		u.stopSecretEntry("Sign-in cancelled.")
		return nil
	}
	if handled, err := t.handleQuestionKey(input); handled || err != nil {
		return err // a note being written stops
	}
	if t.escapeAgent() || len(t.editor.Completions()) > 0 {
		t.editor.Apply(input) // back from a subagent, or suggestions hidden
		return nil
	}
	if _, asking := t.questionChoices(); asking || !u.agentTurnActive() {
		return nil
	}
	return u.interrupt()
}

// leftOpensSessions reports whether Left should open the recent sessions:
// it does on an empty input box with no menu or question showing.
func (t *chatTerminal) leftOpensSessions(input chatEditorInput) bool {
	if input.Key != chatEditorLeft || t.editor.Text() != "" || t.queueEditor.active() || t.u.viewedAgent() != nil {
		return false
	}
	_, asking := t.questionChoices()
	return !asking
}

// chatMenuArrow lets Right choose like Enter and Left go back like Escape
// in the dropdown menus.
func chatMenuArrow(input chatEditorInput) chatEditorInput {
	switch input.Key {
	case chatEditorRight:
		input.Key = chatEditorEnter
	case chatEditorLeft:
		input.Key = chatEditorEscape
	}
	return input
}

// handlePickerKey drives an open model, reasoning, default, fallback, or
// rewind picker. Any other key closes it and goes on to the input box.
func (t *chatTerminal) handlePickerKey(input chatEditorInput) bool {
	if !t.picker.active() {
		return false
	}
	input = chatMenuArrow(input)
	switch input.Key {
	case chatEditorUp:
		t.picker.move(t.u, -1)
	case chatEditorDown:
		t.picker.move(t.u, 1)
	case chatEditorEscape:
		if !t.picker.back(t.u) {
			t.picker.close()
		}
	case chatEditorEnter:
		if err := t.picker.choose(t.u); err != nil {
			t.transcript.append("system", err.Error()+"\n")
		}
		t.applyPrefill()
	default:
		t.picker.close()
		return false
	}
	return true
}

func (t *chatTerminal) handleSessionPickerKey(input chatEditorInput) bool {
	if !t.sessionPicker {
		return false
	}
	u := t.u
	input = chatMenuArrow(input)
	switch input.Key {
	case chatEditorUp:
		t.sessionSelection = max(0, t.sessionSelection-1)
	case chatEditorDown:
		if u.sessions != nil && len(u.sessions.matches) > 0 {
			t.sessionSelection = min(len(u.sessions.matches)-1, t.sessionSelection+1)
		}
	case chatEditorEscape:
		t.sessionPicker, t.resumePickerPending = false, false
	case chatEditorEnter:
		if u.busy {
			t.transcript.append("system", "A turn is running. Cancel or wait before opening a saved session.\n")
		} else if u.sessions != nil && u.sessions.complete && len(u.sessions.matches) > 0 {
			t.sessionPicker = false
			if err := u.resumeChatSessionChoice(strconv.Itoa(t.sessionSelection + 1)); err != nil {
				t.transcript.append("system", err.Error()+"\n")
			}
		}
	default:
		t.sessionPicker, t.resumePickerPending = false, false
		return false
	}
	return true
}

// queueOnTab queues the typed prompt with Tab while a turn runs.
func (t *chatTerminal) queueOnTab(input chatEditorInput) bool {
	u, editor := t.u, t.editor
	text := strings.TrimSpace(editor.Text())
	if t.queueEditor.active() || input.Key != chatEditorTab || !u.agentTurnActive() || !u.threadReady ||
		text == "" || strings.HasPrefix(text, "!") || len(editor.Completions()) > 0 {
		return false
	}
	if err := u.queuePrompt(u.thread, editor.Text()); err != nil {
		t.transcript.append("system", err.Error()+"\n")
	} else {
		editor.SetText("") // the queue rows above the input box show it
	}
	return true
}

// submit handles Enter: it saves an edited queued prompt or runs the line.
func (t *chatTerminal) submit(value string) (done bool, err error) {
	u, editor := t.u, t.editor
	defer t.scroll(0)
	if t.queueEditor.active() {
		t.queueEditor.save(u, editor, value)
		return false, nil
	}
	if u.login.secret != "" { // a key or token goes to the sign-in, never to an agent
		_, err := u.line(value)
		return false, err
	}
	if sent, err := t.submitToAgent(value); sent || err != nil {
		return false, err
	}
	if line := strings.TrimSpace(value); line != "" {
		isCommand := strings.HasPrefix(line, "/") && !strings.HasPrefix(line, "//")
		wasBusy, wasReady, queuedOffline := u.busy, u.threadReady, u.chatOffline() && !isCommand
		busyControl := wasBusy && (line == "/new" || strings.HasPrefix(line, "/resume ") || line == "/compose")
		if line == "/resume" {
			t.picker.close()
			t.resumePickerPending, t.sessionPicker, t.sessionSelection = true, true, 0
		} else if strings.HasPrefix(line, "/sessions") {
			t.resumePickerPending, t.sessionPicker = false, false
		}
		previousSessions := u.sessions
		quit, err := u.line(value)
		if err != nil || quit {
			return true, err
		}
		t.applyAgentViewRequest()
		t.picker.sync(u)
		t.applyPrefill()
		if line == "/resume" && u.sessions == previousSessions {
			t.resumePickerPending, t.sessionPicker = false, false
		}
		// A prompt typed during a turn steers it or queues; only one typed
		// before a conversation opens, or a refused busy command, stays.
		if (busyControl || !isCommand && !wasReady) && !queuedOffline {
			editor.SetText(value) // not sent; keep it to send later
		}
	}
	if id := u.queueEditRequest; id != 0 {
		u.queueEditRequest = 0
		if !t.queueEditor.begin(u, editor, id) {
			t.transcript.append("system", "That queued prompt is no longer available to edit.\n")
		}
	}
	return false, nil
}
